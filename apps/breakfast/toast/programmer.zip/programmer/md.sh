#!/bin/bash


if [ $# -eq 0 ]
then
  echo "Assume default settings"
  python md-cli.py serial@/dev/ttyUSB0:115200 1 --auto scan 1
elif [ $# -eq 1 ]
then
  echo "Using provided USB port ${1}"
  python md-cli.py serial@${1}:115200 1 --auto scan 1
else
  python md-cli.py $@
fi
